package com.example.novelvoicelab

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech as AndroidTts
import android.speech.tts.Voice
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import com.google.mediapipe.tasks.audio.texttospeech.TextToSpeech as EdgeTts
import com.google.mediapipe.tasks.audio.texttospeech.TextToSpeechOptions
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), AndroidTts.OnInitListener {
    private val worker = Executors.newSingleThreadExecutor()
    private var googleTts: AndroidTts? = null
    private var edgeTts: EdgeTts? = null
    private var modelFile: File? = null
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var engine: Spinner
    private lateinit var voice: Spinner
    private lateinit var rate: SeekBar
    private val sample = "天色渐渐暗了下来。屋外传来一阵脚步声，他抬起头，目光落在门口那个人身上。很多事情，他原以为早已过去，如今才发现，不过是刚刚开始。"
    private val voiceIds = listOf("zf_xiaobei（女声）" to "zf_xiaobei", "zm_yunyang（男声）" to "zm_yunyang")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        googleTts = AndroidTts(this, this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        val title = TextView(this).apply { text = "小说声音实验室 · 测试版"; textSize = 22f }
        status = TextView(this).apply { text = "正在初始化 Google TTS…"; textSize = 14f }
        input = EditText(this).apply { setText(sample); minLines = 5; gravity = Gravity.TOP; hint = "输入试听文本" }
        engine = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Google 系统 TTS", "Google AI Edge · Kokoro（离线）")) }
        voice = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, voiceIds.map { it.first }) }
        rate = SeekBar(this).apply { max = 150; progress = 50 }
        val rateLabel = TextView(this).apply { text = "语速：1.0x（可调）" }
        rate.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { rateLabel.text = "语速：${String.format(Locale.US, "%.1f", 0.5 + p / 100f)}x（可调）" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val load = Button(this).apply { text = "选择 Kokoro 模型文件（.litertlm）"; setOnClickListener { pickModel() } }
        val speak = Button(this).apply { text = "试听 / 播放"; setOnClickListener { speak() } }
        val stop = Button(this).apply { text = "停止"; setOnClickListener { googleTts?.stop(); edgeTts?.cancel(); status.text = "已停止" } }
        listOf(title, status, TextView(this).apply { text = "试听文本" }, input,
            TextView(this).apply { text = "合成引擎" }, engine,
            TextView(this).apply { text = "Kokoro 中文音色" }, voice,
            rateLabel, rate, load, speak, stop).forEach { root.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 10 }) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onInit(result: Int) {
        if (result == AndroidTts.SUCCESS) {
            val tts = googleTts ?: return
            val language = tts.setLanguage(Locale.SIMPLIFIED_CHINESE)
            status.text = if (language >= AndroidTts.LANG_AVAILABLE) "Google TTS 已就绪。离线可用性取决于手机是否已下载中文语音包。" else "Google TTS 已启动，但未找到可用的普通话语音包。请在系统语音设置中安装中文语音数据。"
        } else status.text = "Google TTS 初始化失败，请检查系统是否安装语音服务。"
    }

    private fun pickModel() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(intent, 41)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data ?: return
            status.text = "正在导入模型…"
            worker.execute {
                try {
                    val dest = File(filesDir, "kokoro.litertlm")
                    contentResolver.openInputStream(uri)!!.use { input -> dest.outputStream().use { output -> input.copyTo(output) } }
                    modelFile = dest
                    runOnUiThread { status.text = "模型已导入：${dest.length() / (1024 * 1024)} MB。可选择 Kokoro 引擎试听。" }
                } catch (e: Exception) { runOnUiThread { status.text = "模型导入失败：${e.message}" } }
            }
        }
    }

    private fun speak() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) { status.text = "请先输入试听文本"; return }
        val speed = 0.5f + rate.progress / 100f
        if (engine.selectedItemPosition == 0) {
            val tts = googleTts ?: return
            val selected = if (voice.selectedItemPosition == 0) "女声" else "男声"
            val chosen = findChineseVoice(tts, voice.selectedItemPosition == 0)
            if (chosen != null) tts.voice = chosen
            tts.setSpeechRate(speed)
            tts.speak(text, AndroidTts.QUEUE_FLUSH, null, "google-test")
            status.text = "Google 系统 TTS 正在播放（$selected；实际音色以系统语音包为准）"
        } else {
            val file = modelFile
            if (file == null || !file.exists()) { status.text = "请先选择 Kokoro .litertlm 模型文件"; return }
            status.text = "Kokoro 正在本地合成…"
            worker.execute {
                try {
                    val opts = TextToSpeechOptions(
                        BaseOptions.builder().setModelAssetPath(file.absolutePath).setDelegate(Delegate.GPU).build(),
                        voiceIds[voice.selectedItemPosition].second,
                        null,
                        speed,
                        64,
                        cacheDir.absolutePath
                    )
                    if (edgeTts == null) edgeTts = EdgeTts.create(opts)
                    val result = edgeTts!!.synthesize(text)
                    playPcm(result.samples, result.sampleRateHz)
                    runOnUiThread { status.text = "Kokoro 离线合成播放完成。" }
                } catch (e: Exception) { runOnUiThread { status.text = "Kokoro 运行失败：${e.message}" } }
            }
        }
    }

    private fun findChineseVoice(tts: AndroidTts, female: Boolean): Voice? {
        return tts.voices?.filter { it.locale.language == "zh" }?.firstOrNull { v ->
            val n = (v.name + " " + v.features.joinToString(" ")).lowercase(Locale.ROOT)
            if (female) n.contains("female") else n.contains("male")
        } ?: tts.voices?.firstOrNull { it.locale.language == "zh" }
    }

    private fun playPcm(samples: FloatArray, sampleRate: Int) {
        val pcm = ShortArray(samples.size) { i -> (samples[i].coerceIn(-1f, 1f) * Short.MAX_VALUE).toInt().toShort() }
        val min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, pcm.size * 2)).setTransferMode(AudioTrack.MODE_STREAM).build()
        track.play()
        var offset = 0
        while (offset < pcm.size) offset += track.write(pcm, offset, pcm.size - offset)
        track.stop(); track.release()
    }

    override fun onDestroy() {
        googleTts?.stop(); googleTts?.shutdown(); edgeTts?.close(); worker.shutdownNow()
        super.onDestroy()
    }
}
