plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.novelvoicelab"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.novelvoicelab"
        minSdk = 28
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-test"
    }
}

dependencies {
    implementation("com.google.mediapipe:tasks-audio:latest.release")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
}
