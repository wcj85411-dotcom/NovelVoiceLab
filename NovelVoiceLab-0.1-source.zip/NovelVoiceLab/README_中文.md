# 小说声音实验室（双引擎测试版 0.1）

目标设备：红米 K50 至尊 / Android 15。测试引擎：Android 系统 Google TTS + Google AI Edge MediaPipe Kokoro。

## 当前版本说明
- Google TTS：调用系统 `TextToSpeech`，不把语音模型打进 APK。若要离线，必须先在手机的语音服务设置中下载中文语音数据。
- Kokoro：本地加载 `.litertlm` 文件，不需要网络合成。模型文件不打包进 APK；首次测试需手动选择模型文件。
- 目前是声音实验室原型，不是完整小说阅读器。尚未完成后台服务、锁屏控制、自动分段队列、长时间稳定性优化。

## 模型
从 Google AI Edge 官方 MediaPipe TTS 文档链接的 Kokoro-82M 模型库获取适用于 Android 实机的 `kokoro_int8_gpu_fp16.litertlm`（约 295 MB）。保持原始文件名，复制到手机后，在应用内点击“选择 Kokoro 模型文件”。

中文音色初测：`zf_xiaobei`（女）和 `zm_yunyang`（男）。音色是否符合预期，以实机试听为准。

## 构建
项目使用 JDK 17、Gradle 8.9、Android Gradle Plugin 8.7.3、compileSdk 35。可用 Android Studio 打开项目构建，或将项目上传到 GitHub 后运行 `.github/workflows/build.yml`。

## 重要限制
这是第一版工程原型，尚未在红米 K50 至尊实机编译、运行或验证 MediaPipe GPU 兼容性。首次构建需要网络下载 Gradle/Maven 依赖；模型下载可单独进行。若 GPU delegate 在该机型失败，需要进一步增加 CPU 兼容方案并按实测选择模型变体。
